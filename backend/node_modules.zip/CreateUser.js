const express = require('express');
const router = express.Router();
const User =require('./Users')

router.post("/createuser",async(req,res)=>{
    try {
       await User.create({
            rollno:req.body.rollno,
            name:req.body.name,
            email:req.body.email,
            password:req.body.password
        })
        res.json({success:true})
    } catch (error) {
        console.log(error);
        res.json({success:false})
    }
})


router.post("/loginuser",async(req,res)=>{
    let email = req.body.email;
    try {
     let userData = await User.findOne({email});
     if(!userData){
        return res.status(400).json({erors:"credentials doesn't match"})
     }

     if(req.body.password !== userData.password){
        return res.status(400).json({erors:"credentials doesn't match"})
     }
     return res.status(200).json({success:true})

    } catch (error) {
        console.log(error);
        res.json({success:false})
    }
})


module.exports=router;